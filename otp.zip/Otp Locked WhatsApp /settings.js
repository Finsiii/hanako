/*
• Base Ori Irfan X Zerone
Penting ‼️

Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Murni Bikinan Sendiri, Saya Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- Irfan [ Develover Sc ]  
- Zerone [ Support ]
- Pengguna Bot Yang Selalu Support

*/

const settings = {
  token: '-', // Token Bot
  adminId: '6288973380122',
  urladmin: 'https://t.me/FinsiiLacoste',
  domain: '', // Isi dengan domain yang digunakan
  plta: '', // Isi dengan nilai plta yang sesuai
  pltc: '', // Isi dengan nilai pltc yang sesuai
  pp: 'https://telegra.ph/file/31fc0ce288a65c7e335dd.jpg',
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;